const path = require('path');

module.exports = path.dirname(process.mainModule.filename);

//admin.js
//const rootDir = require('../util/path');